import { useState, useEffect } from 'react';
import SearchCard from './components/SearchCard';
import ResultList from './components/ResultList';
import ReverseLookup from './components/ReverseLookup';
import DilutionCalculator from './components/DilutionCalculator';
import { Sprout } from 'lucide-react';

function App() {
  const [db, setDb] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [activePage, setActivePage] = useState('forward');

  const [crop, setCrop] = useState('');
  const [pest, setPest] = useState('');
  const [hasSearched, setHasSearched] = useState(false);
  const [results, setResults] = useState([]);

  // For navigating from forward results to reverse lookup
  const [reverseInitialData, setReverseInitialData] = useState(null);

  useEffect(() => {
    fetch('/pesticide_db.json')
      .then(res => {
        if (!res.ok) throw new Error('無法載入本地資料庫。');
        return res.json();
      })
      .then(data => {
        setDb(data);
        setLoading(false);
      })
      .catch(err => {
        console.error(err);
        setError(err.message);
        setLoading(false);
      });
  }, []);

  const handleSearch = () => {
    if (!crop || !pest) return;

    setHasSearched(true);
    
    const searchCrop = crop.trim().toLowerCase();
    const searchPest = pest.trim().toLowerCase();

    const matchesMap = new Map();

    // 第一遍：找出符合搜尋條件的成分群組
    for (const pesticide of db) {
      if (!pesticide.usageScopes) continue;

      const matchingScope = pesticide.usageScopes.find(scope => {
        const cName = scope['作物名稱'] || '';
        const pName = scope['病蟲害名稱'] || '';
        return cName.toLowerCase().includes(searchCrop) && pName.toLowerCase().includes(searchPest);
      });

      if (matchingScope) {
        const nameKey = pesticide['中文名稱'] || pesticide['英文名稱'] || '未知成分';
        const formulationKey = pesticide['劑型'] || '';
        const contentKey = pesticide['含量'] || '';

        const groupKey = `${nameKey}_${formulationKey}_${contentKey}`;

        if (!matchesMap.has(groupKey)) {
          matchesMap.set(groupKey, {
            id: groupKey,
            name: nameKey,
            formulation: formulationKey,
            content: contentKey,
            classification: pesticide['農藥分類中文意義'] || pesticide['農藥類別中文意義'] || '混合劑',
            matchedScope: matchingScope,
            products: []
          });
        }

        matchesMap.get(groupKey).products.push(pesticide);
      }
    }

    // 第二遍：把整個資料庫中相同成分（名稱/劑型/含量）的所有廠牌都加進來（含農藥製）
    const addedLicenses = new Map();
    for (const [groupKey, group] of matchesMap) {
      addedLicenses.set(groupKey, new Set(group.products.map(p => p['許可證號'])));
    }

    for (const pesticide of db) {
      const nameKey = pesticide['中文名稱'] || pesticide['英文名稱'] || '未知成分';
      const formulationKey = pesticide['劑型'] || '';
      const contentKey = pesticide['含量'] || '';
      const groupKey = `${nameKey}_${formulationKey}_${contentKey}`;

      if (matchesMap.has(groupKey)) {
        const licenseNo = pesticide['許可證號'];
        if (!addedLicenses.get(groupKey).has(licenseNo)) {
          matchesMap.get(groupKey).products.push(pesticide);
          addedLicenses.get(groupKey).add(licenseNo);
        }
      }
    }

    const PRIORITY_VENDORS = ['光華', '春匯'];
    const sortedResults = Array.from(matchesMap.values()).sort((a, b) => {
      const aVendors = new Set(a.products.map(p => {
        const vendor = p['廠商名稱'] || '';
        return PRIORITY_VENDORS.find(v => vendor.includes(v)) || null;
      }).filter(Boolean));
      const bVendors = new Set(b.products.map(p => {
        const vendor = p['廠商名稱'] || '';
        return PRIORITY_VENDORS.find(v => vendor.includes(v)) || null;
      }).filter(Boolean));
      // 有越多優先廠商的排越前面
      return bVendors.size - aVendors.size;
    });

    // 處理複配藥劑作用機制：建立單劑成分字典對照表
    const mechMap = { IRAC: {}, FRAC: {}, HRAC: {} };
    for (const p of db) {
      const eng = p['英文名稱'];
      if (!eng || eng.includes('+')) continue;
      const cleanEng = eng.trim().toUpperCase();
      if (p['IRAC殺蟲劑抗藥性'] && p['IRAC殺蟲劑抗藥性'].trim()) mechMap.IRAC[cleanEng] = p['IRAC殺蟲劑抗藥性'].trim();
      if (p['FRAC殺菌劑抗藥性'] && p['FRAC殺菌劑抗藥性'].trim()) mechMap.FRAC[cleanEng] = p['FRAC殺菌劑抗藥性'].trim();
      if (p['HRAC除草劑抗藥性'] && p['HRAC除草劑抗藥性'].trim()) mechMap.HRAC[cleanEng] = p['HRAC除草劑抗藥性'].trim();
    }

    sortedResults.forEach(group => {
      const p = group.products[0];
      if (!p) return;
      const iracRaw = p['IRAC殺蟲劑抗藥性'];
      const fracRaw = p['FRAC殺菌劑抗藥性'];
      const hracRaw = p['HRAC除草劑抗藥性'];
      
      if (iracRaw && iracRaw.trim()) group.mechanism = `IRAC - ${iracRaw.trim()}`;
      else if (fracRaw && fracRaw.trim()) group.mechanism = `FRAC - ${fracRaw.trim()}`;
      else if (hracRaw && hracRaw.trim()) group.mechanism = `HRAC - ${hracRaw.trim()}`;
      else {
        const eng = p['英文名稱'];
        if (eng && eng.includes('+')) {
          const parts = eng.split('+').map(part => part.trim().toUpperCase());
          const iracs = [], fracs = [], hracs = [];
          parts.forEach(part => {
             if (mechMap.IRAC[part] && !iracs.includes(mechMap.IRAC[part])) iracs.push(mechMap.IRAC[part]);
             if (mechMap.FRAC[part] && !fracs.includes(mechMap.FRAC[part])) fracs.push(mechMap.FRAC[part]);
             if (mechMap.HRAC[part] && !hracs.includes(mechMap.HRAC[part])) hracs.push(mechMap.HRAC[part]);
          });
          
          let result = [];
          if (iracs.length > 0) result.push(`IRAC - ${iracs.join('/')}`);
          if (fracs.length > 0) result.push(`FRAC - ${fracs.join('/')}`);
          if (hracs.length > 0) result.push(`HRAC - ${hracs.join('/')}`);
          if (result.length > 0) group.mechanism = result.join(', ');
        }
      }
    });

    setResults(sortedResults);
  };

  // Navigate from forward card to reverse lookup results
  const navigateToReverse = (groupData) => {
    setReverseInitialData({
      name: groupData.name,
      code: groupData.products[0]?.['農藥代號'] || '',
      englishName: groupData.products[0]?.['英文名稱'] || '',
      formulation: groupData.formulation,
      content: groupData.content,
    });
    setActivePage('reverse');
  };

  // Go back to forward results from reverse lookup
  const goBackToForward = () => {
    setActivePage('forward');
  };

  return (
    <>
      <header className="app-header">
        <div className="container animate-fade-in">
          <div style={{ display: 'flex', flexWrap: 'wrap', alignItems: 'center', justifyContent: 'space-between', gap: '1rem' }}>
            <div className="flex items-center gap-6">
              <a href="https://www.agridoctor.com.tw/" target="_blank" rel="noopener noreferrer" style={{ display: 'flex', alignItems: 'center' }}>
                <img src="/logo.png" alt="光華化學" className="header-logo" onError={(e) => { e.target.onerror = null; e.target.style.display = 'none'; }} />
              </a>
              <div style={{ textAlign: 'left', marginTop: '0.35rem' }}>
                <h1 className="header-title">農藥作物病蟲害查詢器</h1>
                <p className="header-subtitle">為您的農作物量身尋找精準適合的防治對策</p>
              </div>
            </div>
            {/* Tab 切換 */}
            <div style={{ display: 'inline-flex', gap: '0.35rem', background: 'rgba(5,150,105,0.08)', padding: '0.35rem', borderRadius: '999px', border: '1px solid rgba(5,150,105,0.15)' }}>
            <button
              onClick={() => setActivePage('forward')}
              style={{
                padding: '0.5rem 1.25rem',
                borderRadius: '999px',
                border: 'none',
                cursor: 'pointer',
                fontWeight: 600,
                fontSize: '0.9rem',
                background: activePage === 'forward' ? 'white' : 'transparent',
                color: activePage === 'forward' ? 'var(--color-brand-primary)' : '#4b6358',
                boxShadow: activePage === 'forward' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
                transition: 'all 0.2s',
              }}
            >
              作物 + 病蟲害 → 農藥
            </button>
            <button
              onClick={() => { setActivePage('reverse'); setReverseInitialData(null); }}
              style={{
                padding: '0.5rem 1.25rem',
                borderRadius: '999px',
                border: 'none',
                cursor: 'pointer',
                fontWeight: 600,
                fontSize: '0.9rem',
                background: activePage === 'reverse' ? 'white' : 'transparent',
                color: activePage === 'reverse' ? 'var(--color-brand-primary)' : '#4b6358',
                boxShadow: activePage === 'reverse' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
                transition: 'all 0.2s',
              }}
            >
              農藥名稱 → 使用範圍
            </button>
            <button
              onClick={() => setActivePage('calculator')}
              style={{
                padding: '0.5rem 1.25rem',
                borderRadius: '999px',
                border: 'none',
                cursor: 'pointer',
                fontWeight: 600,
                fontSize: '0.9rem',
                background: activePage === 'calculator' ? 'white' : 'transparent',
                color: activePage === 'calculator' ? 'var(--color-brand-primary)' : '#4b6358',
                boxShadow: activePage === 'calculator' ? '0 1px 3px rgba(0,0,0,0.1)' : 'none',
                transition: 'all 0.2s',
              }}
            >
              稀釋 / 成本計算
            </button>
          </div>
          </div>
        </div>
      </header>
      
      <main className="container" style={{ minHeight: '60vh', paddingBottom: '4rem', paddingTop: '3rem' }}>
        {activePage === 'forward' && (
          <SearchCard
            crop={crop}
            setCrop={setCrop}
            pest={pest}
            setPest={setPest}
            onSearch={handleSearch}
          />
        )}
        
        {loading ? (
          <div className="text-center mt-8 animate-fade-in">
            <Sprout size={48} className="mb-4" style={{ animation: 'pulse 2s infinite', opacity: 0.5, color: 'var(--color-brand-light)', margin: '0 auto' }} />
            <p style={{ color: 'var(--color-text-secondary)' }}>正在初始化最新的農藥資料庫...</p>
          </div>
        ) : error ? (
          <div className="text-center mt-8 animate-fade-in text-red-500">
            <p>系統發生錯誤：{error}</p>
          </div>
        ) : activePage === 'reverse' ? (
          <ReverseLookup db={db} initialData={reverseInitialData} onClearInitialData={() => setReverseInitialData(null)} onGoBackToForward={goBackToForward} />
        ) : activePage === 'calculator' ? (
          <DilutionCalculator />
        ) : (
          <ResultList
            results={results}
            hasSearched={hasSearched}
            crop={crop}
            pest={pest}
            onNavigateToReverse={navigateToReverse}
          />
        )}
      </main>

      <footer className="text-center" style={{ padding: '2rem 0', borderTop: '1px solid var(--color-border)', color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>
        <div className="container">
          <p>數據來源：農業部開放資料平臺 (data.moa.gov.tw) - 本系統僅供參考，請依照農藥標示使用。</p>
        </div>
      </footer>
    </>
  );
}

export default App;
